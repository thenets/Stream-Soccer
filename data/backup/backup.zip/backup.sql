-- MySQL dump 10.13  Distrib 5.5.49, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: unifei_soccer
-- ------------------------------------------------------
-- Server version	5.5.49-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `arbitros`
--

DROP TABLE IF EXISTS `arbitros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `arbitros` (
  `id_arbitro` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) DEFAULT NULL,
  `tipo` enum('principal','auxiliar') DEFAULT NULL,
  PRIMARY KEY (`id_arbitro`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `arbitros`
--

LOCK TABLES `arbitros` WRITE;
/*!40000 ALTER TABLE `arbitros` DISABLE KEYS */;
INSERT INTO `arbitros` VALUES (2,'Kratos','principal'),(3,'Teste','auxiliar');
/*!40000 ALTER TABLE `arbitros` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipes`
--

DROP TABLE IF EXISTS `equipes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipes` (
  `id_equipe` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) DEFAULT NULL,
  `titulos` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_equipe`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipes`
--

LOCK TABLES `equipes` WRITE;
/*!40000 ALTER TABLE `equipes` DISABLE KEYS */;
INSERT INTO `equipes` VALUES (1,'São Paulo',5),(2,'Barcelona',10);
/*!40000 ALTER TABLE `equipes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jogadores`
--

DROP TABLE IF EXISTS `jogadores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jogadores` (
  `id_jogador` int(11) NOT NULL AUTO_INCREMENT,
  `id_equipe` int(11) NOT NULL,
  `nome` varchar(45) DEFAULT NULL,
  `posicao` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_jogador`,`id_equipe`),
  KEY `fk_jogador_equipe_idx` (`id_equipe`),
  CONSTRAINT `fk_jogador_equipe` FOREIGN KEY (`id_equipe`) REFERENCES `equipes` (`id_equipe`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jogadores`
--

LOCK TABLES `jogadores` WRITE;
/*!40000 ALTER TABLE `jogadores` DISABLE KEYS */;
INSERT INTO `jogadores` VALUES (1,2,'Lionel Messi','Atacante'),(2,2,'Neymar','Atacante'),(3,2,'Luis Alberto Suarez','Atacante'),(4,2,'Arda Turan','Meia'),(5,2,'Gerard Pique','Zagueiro'),(6,2,'Andres Iniesta','Meia'),(7,2,'Javier Mascherano','Zagueiro'),(8,2,'Denis Suarez','Meia'),(9,2,'Claudio Bravo','Goleiro'),(10,2,'Ivan Rakitic','Meia'),(11,2,'Jordi Alba','Zagueiro'),(12,1,'Paulo Henrique Ganso','Meia'),(13,2,'Aleix Vidal','Zagueiro'),(14,1,'Jonathan Calleri','Atacante'),(15,1,'Maico Pereira Roque','Zagueiro'),(16,1,'Diego Lugano','Zagueiro'),(17,1,'Kelvin Mateus de Oliveira','Atacante'),(18,2,'Sergio Busquets','Meia'),(19,1,'Denis César de Matos','Goleiro'),(20,2,'Sandro Ramirez','Atacante'),(21,1,'Michel Bastos','Meia'),(22,2,'Sergi Roberto','Meia'),(23,1,'Ricardo Centurión','Meia'),(24,1,'Hudson','Meia'),(25,2,'Gerard Gumbau','Meia'),(26,1,'Alan Kardec','Atacante'),(27,1,'Eugenio Mena','Zagueiro'),(28,1,'Rodrigo Caio','Zagueiro'),(29,1,'Ytalo José dos Santos','Atacante'),(30,1,'Breno Vinínius Rodrigues Borges','Zagueiro'),(31,1,'Lucas Cavalcante Silva','Zagueiro'),(32,1,'José Rogério de Oliveira Melo','Atacante'),(33,1,'Lyanco','Zagueiro'),(34,1,'Renan Ribeiro','Goleiro'),(35,1,'Wesley Lopes Beltrame','Meia'),(36,1,'João Schmidt','Meia');
/*!40000 ALTER TABLE `jogadores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jogos`
--

DROP TABLE IF EXISTS `jogos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jogos` (
  `id_jogo` int(11) NOT NULL AUTO_INCREMENT,
  `hora_inicio` timestamp NULL DEFAULT NULL,
  `hora_fim` timestamp NULL DEFAULT NULL,
  `data` date DEFAULT NULL,
  `finalizado` tinyint(1) NOT NULL,
  `campo_nome` varchar(255) NOT NULL,
  `campo_dimensao` varchar(255) NOT NULL,
  `campeonatos_id_campeonato` int(11) NOT NULL,
  `campeonatos_campeao` int(11) NOT NULL,
  `campeonatos_vice` int(11) NOT NULL,
  PRIMARY KEY (`id_jogo`,`campeonatos_id_campeonato`,`campeonatos_campeao`,`campeonatos_vice`),
  KEY `fk_jogos_campeonatos1_idx` (`campeonatos_id_campeonato`,`campeonatos_campeao`,`campeonatos_vice`),
  CONSTRAINT `fk_jogos_campeonatos1` FOREIGN KEY (`campeonatos_id_campeonato`, `campeonatos_campeao`, `campeonatos_vice`) REFERENCES `campeonatos` (`id_campeonato`, `campeao`, `vice`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jogos`
--

LOCK TABLES `jogos` WRITE;
/*!40000 ALTER TABLE `jogos` DISABLE KEYS */;
/*!40000 ALTER TABLE `jogos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sumulas`
--

DROP TABLE IF EXISTS `sumulas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sumulas` (
  `id_sumula` int(11) NOT NULL,
  `id_jogo` int(11) NOT NULL AUTO_INCREMENT,
  `log` text,
  `id_equipe1` int(11) NOT NULL,
  `id_equipe2` int(11) NOT NULL,
  `id_arbitro` int(11) NOT NULL,
  PRIMARY KEY (`id_sumula`,`id_jogo`,`id_equipe1`,`id_equipe2`,`id_arbitro`),
  KEY `fk_sumula_jogo1_idx` (`id_jogo`),
  KEY `fk_sumula_equipe1_idx` (`id_equipe1`),
  KEY `fk_sumula_equipe2_idx` (`id_equipe2`),
  KEY `fk_sumula_arbitro1_idx` (`id_arbitro`),
  CONSTRAINT `fk_sumula_arbitro1` FOREIGN KEY (`id_arbitro`) REFERENCES `arbitros` (`id_arbitro`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_sumula_equipe1` FOREIGN KEY (`id_equipe1`) REFERENCES `equipes` (`id_equipe`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_sumula_equipe2` FOREIGN KEY (`id_equipe2`) REFERENCES `equipes` (`id_equipe`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_sumula_jogo1` FOREIGN KEY (`id_jogo`) REFERENCES `jogos` (`id_jogo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sumulas`
--

LOCK TABLES `sumulas` WRITE;
/*!40000 ALTER TABLE `sumulas` DISABLE KEYS */;
/*!40000 ALTER TABLE `sumulas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sumulasView`
--

DROP TABLE IF EXISTS `sumulasView`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sumulasView` (
  `id_jogo` int(11) NOT NULL AUTO_INCREMENT,
  `id_sumula` int(11) NOT NULL,
  `log` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_jogo`,`id_sumula`),
  KEY `fk_sumula_jogo1_idx` (`id_jogo`),
  CONSTRAINT `fk_sumula_jogo10` FOREIGN KEY (`id_jogo`) REFERENCES `jogos` (`id_jogo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sumulasView`
--

LOCK TABLES `sumulasView` WRITE;
/*!40000 ALTER TABLE `sumulasView` DISABLE KEYS */;
/*!40000 ALTER TABLE `sumulasView` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-06-14 17:44:38
